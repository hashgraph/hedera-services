#!/usr/bin/env bash
echo "I am running"
ls -ltr
