#! /bin/sh
./docker-compile.sh MinimalV3LP.sol 
cp ../bytecodes/MinimalV3LP.bin \
  ~/Dev/hgn3/hedera-services/test-clients/uniswap-go-clients/assets/bytecode/
