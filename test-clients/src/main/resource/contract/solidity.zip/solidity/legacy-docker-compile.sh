#! /bin/sh
set -x
if [ $# -lt 1 ]; then
  echo "USAGE: $0 [source.sol]"
  exit 1
fi
SOLC_VERSION=${2:-'0.4.18'}
CONTRACT=${1%%.*}
ASSETS_DIR="${CONTRACT}-assets"
rm -rf $ASSETS_DIR ; mkdir $ASSETS_DIR
docker run -v $(PWD):/sources \
  ethereum/solc:${SOLC_VERSION} --bin --abi \
  --overwrite \
  --optimize \
  --optimize-runs 700 \
  -o /sources/$ASSETS_DIR \
  /sources/$1
cp $ASSETS_DIR/${CONTRACT}.bin ../bytecodes
