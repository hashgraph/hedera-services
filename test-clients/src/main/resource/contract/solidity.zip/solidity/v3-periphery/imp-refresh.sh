#! /bin/sh
./lp-refresh.sh 
./router-refresh.sh 
./swap-refresh.sh 
