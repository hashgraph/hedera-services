#! /bin/sh
set -x
./docker-compile.sh TypicalV3Swap.sol 
cp TypicalV3Swap-assets/TypicalV3Swap.bin \
  ~/Dev/hgn3/hedera-services/test-clients/uniswap-go-clients/assets/bytecode/
