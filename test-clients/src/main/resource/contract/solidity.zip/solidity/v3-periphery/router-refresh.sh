#! /bin/sh
set -x
./docker-compile.sh SwapRouter.sol 
cp SwapRouter-assets/SwapRouter.bin \
  ~/Dev/hgn3/hedera-services/test-clients/uniswap-go-clients/assets/bytecode/
