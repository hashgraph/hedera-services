#! /bin/sh
set -x
./docker-compile.sh TypicalV3LP.sol 
cp TypicalV3LP-assets/TypicalV3LP.bin \
  ~/Dev/hgn3/hedera-services/test-clients/uniswap-go-clients/assets/bytecode/
