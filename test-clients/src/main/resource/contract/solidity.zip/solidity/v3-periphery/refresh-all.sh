#! /bin/sh
./posManager-refresh.sh 
./lp-refresh.sh 
