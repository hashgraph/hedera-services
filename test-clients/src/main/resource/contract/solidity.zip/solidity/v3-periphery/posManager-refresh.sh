#! /bin/sh
set -x
./docker-compile.sh NonfungiblePositionManager.sol 
cp NonfungiblePositionManager-assets/NonfungiblePositionManager.bin \
  ~/Dev/hgn3/hedera-services/test-clients/uniswap-go-clients/assets/bytecode/
