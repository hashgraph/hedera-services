#! /bin/sh
./docker-compile.sh UniswapV3Factory.sol 
cp ../bytecodes/UniswapV3Factory.bin \
  ~/Dev/hgn3/hedera-services/test-clients/uniswap-go-clients/assets/bytecode/
