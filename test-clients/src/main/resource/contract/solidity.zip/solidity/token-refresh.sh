#! /bin/sh
./docker-compile.sh NamedERC20.sol 0.8.1
cp ../bytecodes/NamedERC20.bin \
  ~/Dev/hgn3/hedera-services/test-clients/uniswap-go-clients/assets/bytecode/
