#! /bin/sh
docker run ethereum/solc:0.7.6 --help
