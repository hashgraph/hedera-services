package com.opencrowd.core;

import com.google.protobuf.ByteString;
import com.hederahashgraph.api.proto.java.AccountID;
import com.hederahashgraph.api.proto.java.Claim;
import com.hederahashgraph.api.proto.java.ContractID;
import com.hederahashgraph.api.proto.java.CryptoAddClaimTransactionBody;
import com.hederahashgraph.api.proto.java.Duration;
import com.hederahashgraph.api.proto.java.ExchangeRate;
import com.hederahashgraph.api.proto.java.ExchangeRateSet;
import com.hederahashgraph.api.proto.java.FileID;
import com.hederahashgraph.api.proto.java.HederaFunctionality;
import com.hederahashgraph.api.proto.java.Key;
import com.hederahashgraph.api.proto.java.KeyList;
import com.hederahashgraph.api.proto.java.Query;
import com.hederahashgraph.api.proto.java.Response;
import com.hederahashgraph.api.proto.java.ResponseCodeEnum;
import com.hederahashgraph.api.proto.java.ResponseType;
import com.hederahashgraph.api.proto.java.Signature;
import com.hederahashgraph.api.proto.java.SignatureList;
import com.hederahashgraph.api.proto.java.SystemDeleteTransactionBody;
import com.hederahashgraph.api.proto.java.Timestamp;
import com.hederahashgraph.api.proto.java.Transaction;
import com.hederahashgraph.api.proto.java.TransactionBody;
import com.hederahashgraph.api.proto.java.TransactionBody.Builder;
import com.hederahashgraph.api.proto.java.TransactionID;
import com.hederahashgraph.api.proto.java.TransactionReceipt;
import com.hederahashgraph.api.proto.java.TransactionRecord;
import com.hederahashgraph.api.proto.java.TransactionResponse;
import com.hederahashgraph.builder.RequestBuilder;
import com.hederahashgraph.builder.TransactionSigner;
import com.hederahashgraph.service.proto.java.CryptoServiceGrpc;
import com.hederahashgraph.service.proto.java.CryptoServiceGrpc.CryptoServiceBlockingStub;
import com.hederahashgraph.service.proto.java.FileServiceGrpc;
import com.hederahashgraph.service.proto.java.FileServiceGrpc.FileServiceBlockingStub;
import com.opencrowd.exception.InvalidNodeTransactionPrecheckCode;
import com.opencrowd.proto.utils.ProtoCommonUtils;
import com.opencrowd.regression.Utilities;
import io.grpc.StatusRuntimeException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;
import net.i2p.crypto.eddsa.EdDSAPublicKey;
import net.i2p.crypto.eddsa.KeyPairGenerator;
import org.apache.commons.codec.DecoderException;
import org.apache.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

/**
 * @author Akshay
 * @Date : 8/14/2018
 */
public class TestHelper {
  private static final org.apache.log4j.Logger log = LogManager.getLogger(TestHelper.class);

  public static long DEFAULT_SEND_RECV_RECORD_THRESHOLD = 5000000000000000000L;
  private static long DEFAULT_WIND_SEC = -13; // seconds to wind back the UTC clock
  private static volatile long lastNano = 0;
  protected static int MAX_RECEIPT_RETRIES = 108000;
  protected static long RETRY_FREQ_MILLIS = 50;
  protected static boolean isExponentialBackoff = false;
  public static String fileName = "StartUpAccount.txt";

  public static Map<String, List<AccountKeyListObj>> getKeyFromFile(Path path) throws IOException {
    StringBuilder data = new StringBuilder();
    Stream<String> lines = Files.lines(path);
    lines.forEach(data::append);
    lines.close();
    byte[] accountKeyPairHolderBytes = CommonUtils.base64decode(String.valueOf(data));
    return (Map<String, List<AccountKeyListObj>>) CommonUtils
        .convertFromBytes(accountKeyPairHolderBytes);
  }

  public static AccountID createFirstAccountFromGenesis(KeyPair firstPair,
      CryptoServiceBlockingStub stub) throws Exception {
    List<AccountKeyListObj> genesisAccount = getGenAccountKey();
    // get Private Key
    PrivateKey genesisPrivateKey = genesisAccount.get(0).getKeyPairList().get(0).getPrivateKey();
    AccountID payerAccount = genesisAccount.get(0).getAccountId();

    AccountID defaultNodeAccount = getDefaultNodeAccount();

    // create 1st account by payer as genesis
    Transaction transaction = TestHelper
        .createAccountWithFee(payerAccount, defaultNodeAccount, firstPair, 1000000l,
            Collections.singletonList(genesisPrivateKey));
    TransactionResponse response = stub.createAccount(transaction);
    Assert.assertNotNull(response);
    Assert.assertEquals(ResponseCodeEnum.OK, response.getNodeTransactionPrecheckCode());
    log.info(
        "Pre Check Response of Create first account :: " + response.getNodeTransactionPrecheckCode()
            .name());

    TransactionBody body = TransactionBody.parseFrom(transaction.getBodyBytes());
    TransactionReceipt txReceipt1 = getTxReceipt(body.getTransactionID(), stub);
    AccountID newlyCreateAccountId1 = txReceipt1.getAccountID();
    Assert.assertNotNull(newlyCreateAccountId1);
    log.info("Account ID " + newlyCreateAccountId1.getAccountNum() + " created successfully.");
    log.info("--------------------------------------");
    return newlyCreateAccountId1;
  }

  public static List<AccountKeyListObj> getGenAccountKey() throws URISyntaxException, IOException {
    Path path = Paths
        .get(Thread.currentThread().getContextClassLoader().getResource(fileName).toURI());
    Map<String, List<AccountKeyListObj>> keyFromFile = getKeyFromFile(path);

    return keyFromFile.get("START_ACCOUNT");
  }

  public static AccountID getDefaultNodeAccount() {
    return RequestBuilder
          .getAccountIdBuild(Utilities.getDefaultNodeAccount(), 0l, 0l);
  }

  public static Transaction createAccountWithFee(AccountID payerAccount, AccountID nodeAccount,
      KeyPair pair, long initialBalance, List<PrivateKey> privKey) throws Exception {

    Transaction transaction = TestHelper
        .createAccount(payerAccount, nodeAccount, pair, initialBalance, 0,
            DEFAULT_SEND_RECV_RECORD_THRESHOLD, DEFAULT_SEND_RECV_RECORD_THRESHOLD);
    Transaction signTransaction = TransactionSigner.signTransaction(transaction, privKey);
    long createAccountFee = FeeClient.getCreateAccountFee(signTransaction,privKey.size());
    System.out.println("createAccountFee ===> " + createAccountFee);
    transaction = TestHelper
        .createAccount(payerAccount, nodeAccount, pair, initialBalance, createAccountFee,
            DEFAULT_SEND_RECV_RECORD_THRESHOLD, DEFAULT_SEND_RECV_RECORD_THRESHOLD);
    signTransaction = TransactionSigner.signTransaction(transaction, privKey);
    return signTransaction;
  }

  public static Transaction createAccountWithFeeAndThresholds(AccountID payerAccount,
      AccountID nodeAccount, KeyPair pair, long initialBalance, List<PrivateKey> privKey,
      long sendRecordThreshold, long receiveRecordThreshold) throws Exception {

    Transaction transaction = TestHelper
        .createAccount(payerAccount, nodeAccount, pair, initialBalance, 0,
            sendRecordThreshold, receiveRecordThreshold);
    Transaction signTransaction = TransactionSigner.signTransaction(transaction, privKey);
    long createAccountFee = FeeClient.getCreateAccountFee(signTransaction,privKey.size());
    System.out.println("createAccountFee ===> " + createAccountFee);
    transaction = TestHelper
        .createAccount(payerAccount, nodeAccount, pair, initialBalance,
            createAccountFee, sendRecordThreshold, receiveRecordThreshold);
    signTransaction = TransactionSigner.signTransaction(transaction, privKey);
    return signTransaction;
  }

  public static Transaction createAccountWithFeeAutoRenewCheck(AccountID payerAccount,
      AccountID nodeAccount,
      KeyPair pair, long initialBalance, List<PrivateKey> privKey) throws Exception {

    Transaction transaction = TestHelper
        .createAccountAutoRenewCheck(payerAccount, nodeAccount, pair, initialBalance, 0);
    Transaction signTransaction = TransactionSigner.signTransaction(transaction, privKey);
    long createAccountFee = FeeClient.getCreateAccountFee(signTransaction,privKey.size());
    System.out.println("createAccountFee ===> " + createAccountFee);
    transaction = TestHelper
        .createAccountAutoRenewCheck(payerAccount, nodeAccount, pair, initialBalance,
            createAccountFee);
    signTransaction = TransactionSigner.signTransaction(transaction, privKey);
    return signTransaction;


  }

  public static Transaction createAccountWithFeeZeroThreshold(AccountID payerAccount,
      AccountID nodeAccount,
      KeyPair pair, long initialBalance, List<PrivateKey> privKey) throws Exception {

    Transaction transaction = TestHelper
        .createAccountZeroThreshold(payerAccount, nodeAccount, pair, initialBalance, 0);
    Transaction signTransaction = TransactionSigner.signTransaction(transaction, privKey);
    long createAccountFee = FeeClient.getCreateAccountFee(signTransaction,privKey.size());
    System.out.println("createAccountFee ===> " + createAccountFee);
    transaction = TestHelper
        .createAccount(payerAccount, nodeAccount, pair, initialBalance, createAccountFee,
            DEFAULT_SEND_RECV_RECORD_THRESHOLD, DEFAULT_SEND_RECV_RECORD_THRESHOLD);
    signTransaction = TransactionSigner.signTransaction(transaction, privKey);
    return signTransaction;


  }

  public static Transaction createAccount(AccountID payerAccount, AccountID nodeAccount,
      KeyPair pair, long initialBalance, long transactionFee, long defaultSendRecordThreshold,
      long defaultRecvRecordThreshold) {
    Timestamp timestamp = TestHelper.getDefaultCurrentTimestampUTC();
    Duration transactionDuration = RequestBuilder.getDuration(30);
    byte[] pubKey = ((EdDSAPublicKey) pair.getPublic()).getAbyte();
    Key key = Key.newBuilder().setEd25519(ByteString.copyFrom(pubKey)).build();
    List<Key> keyList = Collections.singletonList(key);

    boolean generateRecord = true;
    String memo = "Create Account Test";
    boolean receiverSigRequired = false;
    Duration autoRenewPeriod = RequestBuilder.getDuration(5000);

    return RequestBuilder
        .getCreateAccountBuilder(payerAccount.getAccountNum(), payerAccount.getRealmNum(),
            payerAccount.getShardNum(), nodeAccount.getAccountNum(),
            nodeAccount.getRealmNum(), nodeAccount.getShardNum(),
            transactionFee, timestamp, transactionDuration, generateRecord,
            memo, keyList.size(), keyList, initialBalance, defaultSendRecordThreshold,
            defaultRecvRecordThreshold, receiverSigRequired, autoRenewPeriod,
            SignatureList.newBuilder().getDefaultInstanceForType());


  }

  public static Transaction createAccountAutoRenewCheck(AccountID payerAccount,
      AccountID nodeAccount,
      KeyPair pair, long initialBalance, long transactionFee) {
    Timestamp timestamp = TestHelper.getDefaultCurrentTimestampUTC();
    Duration transactionDuration = RequestBuilder.getDuration(30);
    byte[] pubKey = ((EdDSAPublicKey) pair.getPublic()).getAbyte();
//		  String pubKeyStr = Hex.encodeHexString(pubKey);
//		  Key key = Key.newBuilder().setEd25519(ByteString.copyFromUtf8(pubKeyStr)).build();
    Key key = Key.newBuilder().setEd25519(ByteString.copyFrom(pubKey)).build();
    List<Key> keyList = Collections.singletonList(key);

    boolean generateRecord = true;
    String memo = "Create Account Test";
    long sendRecordThreshold = DEFAULT_SEND_RECV_RECORD_THRESHOLD;
    long receiveRecordThreshold = DEFAULT_SEND_RECV_RECORD_THRESHOLD;
    boolean receiverSigRequired = false;
    Duration autoRenewPeriod = RequestBuilder.getDuration(1000000002);

    return RequestBuilder
        .getCreateAccountBuilder(payerAccount.getAccountNum(), payerAccount.getRealmNum(),
            payerAccount.getShardNum(), nodeAccount.getAccountNum(),
            nodeAccount.getRealmNum(), nodeAccount.getShardNum(),
            transactionFee, timestamp, transactionDuration, generateRecord,
            memo, keyList.size(), keyList, initialBalance, sendRecordThreshold,
            receiveRecordThreshold, receiverSigRequired, autoRenewPeriod,
            SignatureList.newBuilder().getDefaultInstanceForType());


  }

  public static Transaction createAccountZeroThreshold(AccountID payerAccount,
      AccountID nodeAccount,
      KeyPair pair, long initialBalance, long transactionFee) {
    Timestamp timestamp = TestHelper.getDefaultCurrentTimestampUTC();
    Duration transactionDuration = RequestBuilder.getDuration(30);
    byte[] pubKey = ((EdDSAPublicKey) pair.getPublic()).getAbyte();
//		  String pubKeyStr = Hex.encodeHexString(pubKey);
//		  Key key = Key.newBuilder().setEd25519(ByteString.copyFromUtf8(pubKeyStr)).build();
    Key key = Key.newBuilder().setEd25519(ByteString.copyFrom(pubKey)).build();
    List<Key> keyList = Collections.singletonList(key);

    boolean generateRecord = false;
    String memo = "Create Account Test";
    long sendRecordThreshold = 0l;
    long receiveRecordThreshold = 0l;
    boolean receiverSigRequired = false;
    Duration autoRenewPeriod = RequestBuilder.getDuration(5000);

    return RequestBuilder
        .getCreateAccountBuilder(payerAccount.getAccountNum(), payerAccount.getRealmNum(),
            payerAccount.getShardNum(), nodeAccount.getAccountNum(),
            nodeAccount.getRealmNum(), nodeAccount.getShardNum(),
            transactionFee, timestamp, transactionDuration, generateRecord,
            memo, keyList.size(), keyList, initialBalance, sendRecordThreshold,
            receiveRecordThreshold, receiverSigRequired, autoRenewPeriod,
            SignatureList.newBuilder().getDefaultInstanceForType());


  }

  public static Transaction createAccountWallet(AccountID payerAccount, AccountID nodeAccount,
      String pubKeyStr, long initialBalance) throws DecoderException {
    Timestamp timestamp = TestHelper.getDefaultCurrentTimestampUTC();
    Duration transactionDuration = RequestBuilder.getDuration(30);
    //		byte[] pubKey = ((EdDSAPublicKey) pair.getPublic()).getAbyte();
//		String pubKeyStr = Hex.encodeHexString(pubKey);
//		  Key key = Key.newBuilder().setEd25519(ByteString.copyFromUtf8(pubKeyStr)).build();
    byte[] bytes = HexUtils.hexToBytes(pubKeyStr);
    Key key = Key.newBuilder().setEd25519(ByteString.copyFrom(bytes)).build();
    List<Key> keyList = Collections.singletonList(key);

    long transactionFee = getMaxFee();
    boolean generateRecord = true;
    String memo = "Create Account Test";
    long sendRecordThreshold = 999;
    long receiveRecordThreshold = 999;
    boolean receiverSigRequired = false;
    Duration autoRenewPeriod = RequestBuilder.getDuration(5000);

    return RequestBuilder
        .getCreateAccountBuilder(payerAccount.getAccountNum(), payerAccount.getRealmNum(),
            payerAccount.getShardNum(), nodeAccount.getAccountNum(),
            nodeAccount.getRealmNum(), nodeAccount.getShardNum(),
            transactionFee, timestamp, transactionDuration, generateRecord,
            memo, keyList.size(), keyList, initialBalance, sendRecordThreshold,
            receiveRecordThreshold, receiverSigRequired, autoRenewPeriod,
            SignatureList.newBuilder().getDefaultInstanceForType());
  }

  /**
   * Gets the transaction receipt.
   *
   * @return the transaction receipt
   */
  public static TransactionReceipt getTxReceipt(TransactionID transactionID,
      CryptoServiceGrpc.CryptoServiceBlockingStub stub, Logger log)
      throws InvalidNodeTransactionPrecheckCode {
    Query query = Query.newBuilder().setTransactionGetReceipt(
        RequestBuilder.getTransactionGetReceiptQuery(transactionID, ResponseType.ANSWER_ONLY))
        .build();

    TransactionReceipt rv;
    Response transactionReceipts = fetchReceipts(query, stub, log);
    rv = transactionReceipts.getTransactionGetReceipt().getReceipt();
    return rv;
  }

  /**
   * Gets the transaction receipt.
   *
   * @return the transaction receipt
   */
  public static TransactionReceipt getTxReceipt(TransactionID transactionID,
      CryptoServiceGrpc.CryptoServiceBlockingStub stub)
      throws InvalidNodeTransactionPrecheckCode {
    return getTxReceipt(transactionID, stub, null);
  }

  public static TransactionRecord getFastTxRecord(TransactionID transactionID,
      CryptoServiceGrpc.CryptoServiceBlockingStub stub) {
    Query query = Query.newBuilder().setTransactionGetFastRecord(
        RequestBuilder.getFastTransactionRecordQuery(transactionID, ResponseType.ANSWER_ONLY))
        .build();

    return stub.getFastTransactionRecord(query).getTransactionGetFastRecord()
        .getTransactionRecord();
  }


  public static Response getCryptoGetAccountInfo(CryptoServiceGrpc.CryptoServiceBlockingStub stub,
      AccountID accountID, AccountID payerAccount,
      PrivateKey payerAccountKey, AccountID nodeAccount) throws Exception {

    // first get the fee for getting the account info

    long costForQuery = FeeClient.getCostForGettingAccountInfo();
    System.out.println(costForQuery + " :: is the cost for query");
    Response response = executeAccountInfoQuery(stub, accountID, payerAccount, payerAccountKey,
        nodeAccount, costForQuery, ResponseType.COST_ANSWER);

    if (response.getCryptoGetInfo().getHeader().getNodeTransactionPrecheckCode()
        == ResponseCodeEnum.OK) {
      long getAcctFee = response.getCryptoGetInfo().getHeader().getCost();
      response = executeAccountInfoQuery(stub, accountID, payerAccount, payerAccountKey,
          nodeAccount,
          getAcctFee, ResponseType.ANSWER_ONLY);
    }
    return response;
  }

  public static Response executeAccountInfoQuery(CryptoServiceGrpc.CryptoServiceBlockingStub stub,
      AccountID accountID, AccountID payerAccount, PrivateKey payerAccountKey,
      AccountID nodeAccount, long costForQuery, ResponseType responseType) throws Exception {
    Transaction transferTransaction = createTransfer(payerAccount, payerAccountKey, nodeAccount,
        payerAccount, payerAccountKey, nodeAccount, costForQuery);
    Query cryptoGetInfoQuery = RequestBuilder
        .getCryptoGetInfoQuery(accountID, transferTransaction, responseType);
    return stub.getAccountInfo(cryptoGetInfoQuery);
  }

  public static Response getCryptoGetBalance(CryptoServiceGrpc.CryptoServiceBlockingStub stub,
      AccountID accountID, AccountID payerAccount,
      PrivateKey payerAccountKey, AccountID nodeAccount) {

    long costForQuery = FeeClient.getFeeByID(HederaFunctionality.CryptoGetAccountBalance) + 50000;
    System.out.println(costForQuery + " :: is the cost for query");
    Response response = executeGetBalanceQuery(stub, accountID, payerAccount, payerAccountKey,
        nodeAccount, costForQuery, ResponseType.COST_ANSWER);

    if (response.getCryptogetAccountBalance().getHeader().getNodeTransactionPrecheckCode()
        == ResponseCodeEnum.OK) {
      long getAcctFee = response.getCryptogetAccountBalance().getHeader().getCost();
      response = executeGetBalanceQuery(stub, accountID, payerAccount, payerAccountKey,
          nodeAccount, getAcctFee, ResponseType.ANSWER_ONLY);
    }
    return response;
  }

  private static Response executeGetBalanceQuery(CryptoServiceGrpc.CryptoServiceBlockingStub stub,
      AccountID accountID, AccountID payerAccount, PrivateKey payerAccountKey,
      AccountID nodeAccount, long costForQuery, ResponseType responseType) {
    Transaction transferTransaction = createTransfer(payerAccount, payerAccountKey, nodeAccount,
        payerAccount, payerAccountKey, nodeAccount, costForQuery);
    Query getBalanceQuery = RequestBuilder
        .getCryptoGetBalanceQuery(accountID, transferTransaction, responseType);
    return stub.cryptoGetBalance(getBalanceQuery);
  }

  public static Response getTxRecordByTxID(CryptoServiceGrpc.CryptoServiceBlockingStub stub,
      TransactionID transactionID, AccountID payerAccount, PrivateKey payerAccountKey,
      AccountID nodeAccount) {

    long costForQuery = FeeClient.getCostForGettingTxRecord();
    System.out.println(costForQuery + " :: is the cost for query");
    Response response = executeTxRecordByTxID(stub, transactionID, payerAccount, payerAccountKey,
        nodeAccount, costForQuery, ResponseType.COST_ANSWER);

    if (response.getTransactionGetRecord().getHeader().getNodeTransactionPrecheckCode()
        == ResponseCodeEnum.OK) {
      long getAcctFee = response.getTransactionGetRecord().getHeader().getCost();
      response = executeTxRecordByTxID(stub, transactionID, payerAccount, payerAccountKey,
          nodeAccount, getAcctFee, ResponseType.ANSWER_ONLY);
    }
    return response;
  }

  private static Response executeTxRecordByTxID(CryptoServiceGrpc.CryptoServiceBlockingStub stub,
      TransactionID transactionID, AccountID payerAccount, PrivateKey payerAccountKey,
      AccountID nodeAccount, long costForQuery, ResponseType responseType) {
    Transaction transferTransaction = createTransfer(payerAccount, payerAccountKey, nodeAccount,
        payerAccount, payerAccountKey, nodeAccount, costForQuery);
    Query query = RequestBuilder.getTransactionGetRecordQuery(transactionID, transferTransaction,
        responseType);
    return stub.getTxRecordByTxID(query);
  }

  public static Response getAccountRecords(CryptoServiceGrpc.CryptoServiceBlockingStub stub,
      AccountID accountId, AccountID payerAccount, PrivateKey payerAccountKey,
      AccountID nodeAccount) {

    long costForQuery = FeeClient.getFeeByID(HederaFunctionality.CryptoGetAccountRecords);
    System.out.println(costForQuery + " :: is the cost for query");
    Response response = executeGetAccountRecords(stub, accountId, payerAccount, payerAccountKey,
        nodeAccount, costForQuery, ResponseType.COST_ANSWER);

    if (response.getCryptoGetAccountRecords().getHeader().getNodeTransactionPrecheckCode()
        == ResponseCodeEnum.OK) {
      long getAcctFee = response.getCryptoGetAccountRecords().getHeader().getCost();
      response = executeGetAccountRecords(stub, accountId, payerAccount, payerAccountKey,
          nodeAccount, getAcctFee, ResponseType.ANSWER_ONLY);
    }
    return response;
  }

  private static Response executeGetAccountRecords(CryptoServiceGrpc.CryptoServiceBlockingStub stub,
      AccountID accountID, AccountID payerAccount, PrivateKey payerAccountKey,
      AccountID nodeAccount, long costForQuery, ResponseType responseType) {
    Transaction transferTransaction = createTransfer(payerAccount, payerAccountKey, nodeAccount,
        payerAccount, payerAccountKey, nodeAccount, costForQuery);
    Query query = RequestBuilder.getAccountRecordsQuery(accountID, transferTransaction,
        responseType);
    return stub.getAccountRecords(query);
  }

  public static Response getAccountClaim(CryptoServiceGrpc.CryptoServiceBlockingStub stub,
      AccountID accountId, byte[] hash, AccountID payerAccount, PrivateKey payerAccountKey,
      AccountID nodeAccount) {

    long costForQuery = FeeClient.getFeeByID(HederaFunctionality.CryptoGetClaim);
    System.out.println(costForQuery + " :: is the cost for query");
    Response response = executeGetAccountClaim(stub, accountId, hash, payerAccount, payerAccountKey,
        nodeAccount, costForQuery, ResponseType.COST_ANSWER);

    if (response.getCryptoGetClaim().getHeader().getNodeTransactionPrecheckCode()
        == ResponseCodeEnum.OK) {
      long getAcctFee = response.getCryptoGetClaim().getHeader().getCost();
      response = executeGetAccountClaim(stub, accountId, hash, payerAccount, payerAccountKey,
          nodeAccount, getAcctFee, ResponseType.ANSWER_ONLY);
    }
    return response;
  }

  private static Response executeGetAccountClaim(CryptoServiceGrpc.CryptoServiceBlockingStub stub,
      AccountID accountID, byte[] hash, AccountID payerAccount, PrivateKey payerAccountKey,
      AccountID nodeAccount, long costForQuery, ResponseType responseType) {
    Transaction transferTransaction = createTransfer(payerAccount, payerAccountKey, nodeAccount,
        payerAccount, payerAccountKey, nodeAccount, costForQuery);
    Query query = RequestBuilder.getAccountClaimQuery(accountID, hash, transferTransaction,
        responseType);
    return stub.getClaim(query);
  }

  public static Transaction updateAccount(AccountID accountID, AccountID payerAccount,
      PrivateKey payerAccountKey, AccountID nodeAccount, Duration autoRenew) {

    Timestamp startTime = TestHelper.getDefaultCurrentTimestampUTC();
    Duration transactionDuration = RequestBuilder.getDuration(30);

    long nodeAccountNum = nodeAccount.getAccountNum();
    long payerAccountNum = payerAccount.getAccountNum();
    return RequestBuilder.getAccountUpdateRequest(accountID, payerAccountNum, 0l,
        0l, nodeAccountNum, 0l,
        0l, getMaxFee(), startTime,
        transactionDuration, true, "Update Account",
        100l, 100l,
        autoRenew, SignatureList.newBuilder().getDefaultInstanceForType());


  }

  public static Transaction deleteAccount(AccountID accountID, AccountID trasferAccountID,
      AccountID payerAccount,
      PrivateKey payerAccountKey, AccountID nodeAccount) {
    Timestamp startTime = TestHelper.getDefaultCurrentTimestampUTC();
    Duration transactionDuration = RequestBuilder.getDuration(30);

    long nodeAccountNum = nodeAccount.getAccountNum();
    long payerAccountNum = payerAccount.getAccountNum();
    return RequestBuilder.getAccountDeleteRequest(accountID, trasferAccountID, payerAccountNum, 0l,
        0l, nodeAccountNum, 0l,
        0l, getMaxFee(), startTime,
        transactionDuration, true, "Delete Account",
        SignatureList.newBuilder().getDefaultInstanceForType());
  }

  public static Transaction createFile(long payerAccountNum,
      Long nodeAccountNum, long transactionFee,
      boolean generateRecord, String memo,
      ByteString fileData, Timestamp fileExpirationTime) {

    Timestamp startTime = TestHelper.getDefaultCurrentTimestampUTC();
    Duration transactionDuration = RequestBuilder.getDuration(30);
    List<Key> waclKeyList = new ArrayList<>();
    KeyPair pair = new KeyPairGenerator().generateKeyPair();
    Key waclKey = Key.newBuilder()
        .setEd25519(ByteString.copyFrom(pair.getPublic().toString().getBytes())).build();
    waclKeyList.add(waclKey);

    return RequestBuilder.getFileCreateBuilder(payerAccountNum, 0l, 0l, nodeAccountNum, 0l, 0l,
        transactionFee, startTime, transactionDuration, generateRecord, memo,
        SignatureList.newBuilder().getDefaultInstanceForType(), fileData,
        fileExpirationTime, waclKeyList);
  }


  public static Transaction createAccountmultiSig(AccountID payerAccount, AccountID nodeAccount,
      List<KeyPair> listKeyPairs, long initialBalance, PrivateKey genesisPrivateKey)
      throws Exception {
    Timestamp timestamp = TestHelper.getDefaultCurrentTimestampUTC();
    Duration transactionDuration = RequestBuilder.getDuration(30);
    List<Key> keyList = new ArrayList<>();
    int i = listKeyPairs.size();
    for (int j = 0; j < i; j++) {
      byte[] pubKey = ((EdDSAPublicKey) listKeyPairs.get(j).getPublic()).getAbyte();
//			String pubKeyStr = Hex.encodeHexString(pubKey);
//			Key key = Key.newBuilder().setEd25519(ByteString.copyFromUtf8(pubKeyStr)).build();
      Key key = Key.newBuilder().setEd25519(ByteString.copyFrom(pubKey)).build();
      keyList.add(j, key);
    }
    long transactionFee = 10l;
    boolean generateRecord = true;
    String memo = "Create Account Test";
    long sendRecordThreshold = 1000000l;
    long receiveRecordThreshold = 1000000l;
    boolean receiverSigRequired = false;
    Duration autoRenewPeriod = RequestBuilder.getDuration(5000);

    Transaction transaction = RequestBuilder
        .getCreateAccountBuilder(payerAccount.getAccountNum(), payerAccount.getRealmNum(),
            payerAccount.getShardNum(), nodeAccount.getAccountNum(),
            nodeAccount.getRealmNum(), nodeAccount.getShardNum(),
            transactionFee, timestamp, transactionDuration, generateRecord,
            memo, keyList.size(), keyList, initialBalance, sendRecordThreshold,
            receiveRecordThreshold, receiverSigRequired, autoRenewPeriod,
            SignatureList.newBuilder().getDefaultInstanceForType());
    transaction = TransactionSigner
        .signTransaction(transaction, Collections.singletonList(genesisPrivateKey));
// Since Single Genesis Key is used
    transactionFee = FeeClient.getCreateAccountFee(transaction,1);

    transaction = RequestBuilder
        .getCreateAccountBuilder(payerAccount.getAccountNum(), payerAccount.getRealmNum(),
            payerAccount.getShardNum(), nodeAccount.getAccountNum(),
            nodeAccount.getRealmNum(), nodeAccount.getShardNum(),
            transactionFee, timestamp, transactionDuration, generateRecord,
            memo, keyList.size(), keyList, initialBalance, sendRecordThreshold,
            receiveRecordThreshold, receiverSigRequired, autoRenewPeriod,
            SignatureList.newBuilder().getDefaultInstanceForType());
    return TransactionSigner
        .signTransaction(transaction, Collections.singletonList(genesisPrivateKey));


  }

  public static Properties getApplicationProperties() {
    Properties prop = new Properties();
    InputStream input;
    try {
      String rootPath = Thread.currentThread().getContextClassLoader().getResource("").getPath();
      input = new FileInputStream(rootPath + "application.properties");
      prop.load(input);
    } catch (IOException e) {
      e.printStackTrace();
    }
    return prop;
  }

  /**
   * Gets the application properties as a more friendly CustomProperties object.
   */
  public static CustomProperties getApplicationPropertiesNew() {
    String propertyFile = "application.properties";
    CustomProperties props = new CustomProperties(propertyFile);
    return props;
  }

  public static Response getFileContent(FileServiceGrpc.FileServiceBlockingStub fileStub,
      FileID fileID, AccountID payerAccount,
      PrivateKey payerAccountKey, AccountID nodeAccount) throws Exception {
    long getContentFee = getMaxFee();
    Transaction transferTransaction = createTransfer(payerAccount, payerAccountKey, nodeAccount,
        payerAccount, payerAccountKey, nodeAccount, getContentFee);
    Query fileContentQuery = RequestBuilder
        .getFileContentQuery(fileID, transferTransaction, ResponseType.ANSWER_ONLY);
    return fileStub.getFileContent(fileContentQuery);
  }

  public static Query getTxRecordByTxId(TransactionID transactionID, AccountID payerAccount,
      PrivateKey payerAccountKey, AccountID nodeAccount, long getTxRecordFee,
      ResponseType reponseType) {

    Transaction transferTransaction = createTransfer(payerAccount, payerAccountKey, nodeAccount,
        payerAccount, payerAccountKey, nodeAccount, getTxRecordFee);

    return RequestBuilder
        .getTransactionGetRecordQuery(transactionID, transferTransaction, reponseType);
  }

  public static Query getTxRecordByAccountId(AccountID accountID, AccountID payerAccount,
      PrivateKey payerAccountKey, AccountID nodeAccount, long getTxRecordFee,
      ResponseType responsetype) throws Exception {
    getTxRecordFee = getMaxFee();
    Transaction transferTransaction = createTransfer(payerAccount, payerAccountKey, nodeAccount,
        payerAccount, payerAccountKey, nodeAccount, getTxRecordFee);
    return RequestBuilder.getAccountRecordsQuery(accountID, transferTransaction, responsetype);
  }

  public static Query getTxRecordByContractId(ContractID contractID, AccountID payerAccount,
      PrivateKey payerAccountKey, AccountID nodeAccount, long getTxRecordFee,
      ResponseType responseType) throws Exception {
    Transaction transferTransaction = createTransfer(payerAccount, payerAccountKey, nodeAccount,
        payerAccount, payerAccountKey, nodeAccount, getTxRecordFee);
    return RequestBuilder.getContractRecordsQuery(contractID, transferTransaction, responseType);
  }

  public static Transaction createTransfer(AccountID fromAccount, PrivateKey fromKey,
      AccountID toAccount,
      AccountID payerAccount, PrivateKey payerAccountKey, AccountID nodeAccount,
      long amount) {
    Timestamp timestamp = TestHelper.getDefaultCurrentTimestampUTC();
    Duration transactionDuration = RequestBuilder.getDuration(30);

    SignatureList sigList = SignatureList.getDefaultInstance();
    Transaction transferTx = RequestBuilder.getCryptoTransferRequest(payerAccount.getAccountNum(),
        payerAccount.getRealmNum(), payerAccount.getShardNum(), nodeAccount.getAccountNum(),
        nodeAccount.getRealmNum(), nodeAccount.getShardNum(), 0, timestamp, transactionDuration,
        false,
        "Test Transfer", sigList, fromAccount.getAccountNum(), -amount, toAccount.getAccountNum(),
        amount);
    // sign the tx
    List<List<PrivateKey>> privKeysList = new ArrayList<>();
    List<PrivateKey> payerPrivKeyList = new ArrayList<>();
    payerPrivKeyList.add(payerAccountKey);
    privKeysList.add(payerPrivKeyList);

    List<PrivateKey> fromPrivKeyList = new ArrayList<>();
    fromPrivKeyList.add(fromKey);
    privKeysList.add(fromPrivKeyList);

    Transaction signedTx = TransactionSigner.signTransactionNew(transferTx, privKeysList);

    long transferFee = 0;
    try {
      transferFee = FeeClient.getTransferFee(signedTx,privKeysList.size());
    } catch (Exception e) {
      e.printStackTrace();
    }
    transferTx = RequestBuilder.getCryptoTransferRequest(payerAccount.getAccountNum(),
        payerAccount.getRealmNum(), payerAccount.getShardNum(), nodeAccount.getAccountNum(),
        nodeAccount.getRealmNum(), nodeAccount.getShardNum(), transferFee, timestamp,
        transactionDuration, false,
        "Test Transfer", sigList, fromAccount.getAccountNum(), -amount, toAccount.getAccountNum(),
        amount);

    signedTx = TransactionSigner.signTransactionNew(transferTx, privKeysList);
    return signedTx;
  }

  /**
   * Fetches the receipts, wait if necessary.
   *
   * @return the response
   */
  public static Response fetchReceipts(final Query query, final CryptoServiceBlockingStub cstub,
      final Logger log)
      throws InvalidNodeTransactionPrecheckCode {
    long start = System.currentTimeMillis();
    if (log != null) {
      log.debug("GetTxReceipt: query=" + query);
    }

    Response transactionReceipts = cstub.getTransactionReceipts(query);
    Assert.assertNotNull(transactionReceipts);
    ResponseCodeEnum precheckCode = transactionReceipts.getTransactionGetReceipt().getHeader()
        .getNodeTransactionPrecheckCode();
    if (!precheckCode.equals(ResponseCodeEnum.OK)) {
      throw new InvalidNodeTransactionPrecheckCode("Invalid node transaction precheck code " +
          precheckCode.name() +
          " from getTransactionReceipts");
    }

    int cnt = 0;
    String status = transactionReceipts.getTransactionGetReceipt().getReceipt().getStatus().name();
    while (cnt < MAX_RECEIPT_RETRIES && status.equals(ResponseCodeEnum.UNKNOWN.name())) {
      long napMillis = RETRY_FREQ_MILLIS;
      if(isExponentialBackoff)
        napMillis = getExpWaitTimeMillis(cnt, RETRY_FREQ_MILLIS);
      CommonUtils.napMillis(napMillis );
      cnt++;
      try {
        transactionReceipts = cstub.getTransactionReceipts(query);
        status = transactionReceipts.getTransactionGetReceipt().getReceipt().getStatus().name();
      } catch (StatusRuntimeException e) {
        if (log != null) {
          log.warn("getTransactionReceipts: RPC failed!", e);
        }
        status = ResponseCodeEnum.UNKNOWN.name();
      }
    }

    long elapse = System.currentTimeMillis() - start;
    long secs = elapse / 1000;
    long milliSec = elapse % 1000;
    String msg = "GetTxReceipt: took = " + secs + " second " + milliSec + " millisec; retries = " + cnt + "; receipt=" + transactionReceipts;
    if (!status.equals(ResponseCodeEnum.SUCCESS.name())) {
      if (log != null) {
        log.warn(msg);
      }
    } else {
      if (log != null) {
        log.info(msg);
      }
    }
    return transactionReceipts;
  }

  /**
   * Exponential wait time in millis capped by a max wait time.
   * 
   * @param retries num of retries
   * @param maxWaitMillis beyond which, the wait time will be this value
   * @return the wait time in millis
   */
  private static long getExpWaitTimeMillis(int retries, long maxWaitMillis) {
    double rv = 0;
    rv = (Math.pow(2, retries) * RETRY_FREQ_MILLIS);
    
    if(rv > maxWaitMillis)
      rv = maxWaitMillis;
    
    long waitMillis = (long) rv;
    
    return waitMillis;
  }
  
  /**
   * Gets the current UTC timestamp with default winding back seconds.
   */
  public synchronized static Timestamp getDefaultCurrentTimestampUTC() {
    Timestamp rv = ProtoCommonUtils.getCurrentTimestampUTC(DEFAULT_WIND_SEC);
    if (rv.getNanos() == lastNano) {
      try {
        Thread.sleep(0, 1);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
      rv = ProtoCommonUtils.getCurrentTimestampUTC(DEFAULT_WIND_SEC);
    }

    lastNano = rv.getNanos();

    return rv;
  }


  public static Transaction getContractCallRequest(Long payerAccountNum, Long payerRealmNum,
      Long payerShardNum,
      Long nodeAccountNum, Long nodeRealmNum, Long nodeShardNum,
      long transactionFee, Timestamp timestamp,
      Duration txDuration, long gas, ContractID contractId,
      ByteString functionData, long value,
      List<PrivateKey> keys) throws Exception {

    Transaction transaction = RequestBuilder
        .getContractCallRequest(payerAccountNum, payerRealmNum, payerShardNum, nodeAccountNum,
            nodeRealmNum, nodeShardNum, transactionFee, timestamp,
            txDuration, gas, contractId, functionData, value,
            SignatureList.newBuilder().
                addSigs(Signature.newBuilder()
                    .setEd25519(ByteString.copyFrom("testsignature".getBytes()))).build());

    transaction = TransactionSigner.signTransaction(transaction, keys);

    transactionFee = FeeClient.getCostContractCallFee(transaction, keys.size());

    transaction = RequestBuilder
        .getContractCallRequest(payerAccountNum, payerRealmNum, payerShardNum, nodeAccountNum,
            nodeRealmNum, nodeShardNum, transactionFee, timestamp,
            txDuration, gas, contractId, functionData, value,
            SignatureList.newBuilder().
                addSigs(Signature.newBuilder()
                    .setEd25519(ByteString.copyFrom("testsignature".getBytes()))).build());

    return TransactionSigner.signTransaction(transaction, keys);

  }

  public static Transaction getCreateContractRequest(Long payerAccountNum, Long payerRealmNum,
      Long payerShardNum,
      Long nodeAccountNum, Long nodeRealmNum, Long nodeShardNum,
      long transactionFee, Timestamp timestamp, Duration txDuration,
      boolean generateRecord, String txMemo, long gas, FileID fileId,
      ByteString constructorParameters, long initialBalance,
      Duration autoRenewalPeriod, List<PrivateKey> keys, String contractMemo) throws Exception {
    return getCreateContractRequest(payerAccountNum, payerRealmNum, payerShardNum,
        nodeAccountNum, nodeRealmNum, nodeShardNum,
        transactionFee, timestamp, txDuration,
        generateRecord, txMemo, gas, fileId,
        constructorParameters, initialBalance,
        autoRenewalPeriod, keys, contractMemo, null);
  }

  public static Transaction getCreateContractRequest(Long payerAccountNum, Long payerRealmNum,
      Long payerShardNum,
      Long nodeAccountNum, Long nodeRealmNum, Long nodeShardNum,
      long transactionFee, Timestamp timestamp, Duration txDuration,
      boolean generateRecord, String txMemo, long gas, FileID fileId,
      ByteString constructorParameters, long initialBalance,
      Duration autoRenewalPeriod, List<PrivateKey> keys, String contractMemo,
      Key adminKey) throws Exception {

    Transaction transaction = RequestBuilder
        .getCreateContractRequest(payerAccountNum, payerRealmNum, payerShardNum, nodeAccountNum,
            nodeRealmNum, nodeShardNum, transactionFee, timestamp,
            txDuration, generateRecord, txMemo, gas, fileId, constructorParameters, initialBalance,
            autoRenewalPeriod, SignatureList.newBuilder()
                .addSigs(Signature.newBuilder()
                    .setEd25519(ByteString.copyFrom("testsignature".getBytes())))
                .build(), contractMemo, adminKey);

    transaction = TransactionSigner.signTransaction(transaction, keys);

    transactionFee = FeeClient.getContractCreateFee(transaction,keys.size());

    transaction = RequestBuilder
        .getCreateContractRequest(payerAccountNum, payerRealmNum, payerShardNum, nodeAccountNum,
            nodeRealmNum, nodeShardNum, transactionFee, timestamp,
            txDuration, generateRecord, txMemo, gas, fileId, constructorParameters, initialBalance,
            autoRenewalPeriod, SignatureList.newBuilder()
                .addSigs(Signature.newBuilder()
                    .setEd25519(ByteString.copyFrom("testsignature".getBytes())))
                .build(), contractMemo, adminKey);

    transaction = TransactionSigner.signTransaction(transaction, keys);
    return transaction;
  }

  public static long getMaxFee() {
    return FeeClient.getMaxFee();
  }

  public static Transaction getSystemDeleteTx(PrivateKey payerPrivateKey, AccountID payerAccount,
      AccountID defaultNodeAccount, FileID fileID, long expireTimeInSeconds) throws Exception {

    Timestamp startTime = TestHelper.getDefaultCurrentTimestampUTC();
    Duration transactionDuration = RequestBuilder.getDuration(30);
    // prepare tx Body
    TransactionBody.Builder body = RequestBuilder
        .getTxBodyBuilder(30, startTime, transactionDuration,
            true, "System Delete", payerAccount, defaultNodeAccount);

    // prepare specif request body
    SystemDeleteTransactionBody systemDeleteTransactionBody =
        RequestBuilder.getSystemDeleteTransactionBody(fileID, expireTimeInSeconds);
    body.setSystemDelete(systemDeleteTransactionBody);
    ByteString bodyBytes = ByteString.copyFrom(body.build().toByteArray());

    // step 1 : create tx
    Transaction transaction = Transaction.newBuilder().setBodyBytes(bodyBytes)
        .setSigs(SignatureList.getDefaultInstance()).build();
    // step 2 : sign tx by payer account's private key
    Transaction signTransaction = TransactionSigner.signTransaction(transaction,
        Collections.singletonList(payerPrivateKey));
    // step 3 calculate fee after signing tx
    long systemDeleteFee = FeeClient.getSystemDeleteFee(signTransaction);
    // step 4 setting fee to body
    body.setTransactionFee(systemDeleteFee);
    System.out.println("SystemDelete Fee ===> " + systemDeleteFee);
    // step 5  sign again after fee calculation
    transaction = Transaction.newBuilder()
        .setBodyBytes(ByteString.copyFrom(body.build().toByteArray()))
        .setSigs(SignatureList.getDefaultInstance()).build();
    signTransaction = TransactionSigner.signTransaction(transaction,
        Collections.singletonList(payerPrivateKey));
    return signTransaction;
  }

  public static Response getFileInfo(FileServiceBlockingStub stub,
      FileID fileID, AccountID payerAccount, PrivateKey payerAccountKey, AccountID nodeAccount) {

    // first get the fee for getting the file info
    long feeForFileInfoCost = FeeClient.getFeeByID(HederaFunctionality.FileGetInfo);
    Response response = executeFileInfoQuery(stub, fileID, payerAccount, payerAccountKey,
        nodeAccount, feeForFileInfoCost, ResponseType.COST_ANSWER);

    long getFileFee = response.getFileGetInfo().getHeader().getCost();
    response = executeFileInfoQuery(stub, fileID, payerAccount, payerAccountKey, nodeAccount,
        getFileFee, ResponseType.ANSWER_ONLY);
    return response;
  }

  private static Response executeFileInfoQuery(FileServiceBlockingStub stub,
      FileID fileId, AccountID payerAccount, PrivateKey payerAccountKey,
      AccountID nodeAccount, long costForQuery, ResponseType responseType) {
    Transaction transferTransaction = createTransfer(payerAccount, payerAccountKey, nodeAccount,
        payerAccount, payerAccountKey, nodeAccount, costForQuery);
    Query fileGetInfoBuilder = RequestBuilder
        .getFileGetInfoBuilder(transferTransaction, fileId, responseType);
    return stub.getFileInfo(fileGetInfoBuilder);
  }

  public static Transaction getDeleteContractRequest(AccountID payer,
      AccountID node,
      long transactionFee, Timestamp timestamp, Duration txDuration,
      boolean generateRecord, String txMemo, ContractID contractId, AccountID transferAccount,
      ContractID transferContract, List<PrivateKey> keys) throws Exception {

    Transaction transaction = RequestBuilder
        .getDeleteContractRequest(payer, node, transactionFee, timestamp, txDuration, contractId,
            transferAccount, transferContract, generateRecord, txMemo, SignatureList.newBuilder()
                .addSigs(Signature.newBuilder()
                    .setEd25519(ByteString.copyFrom("testsignature".getBytes())))
                .build());

    transaction = TransactionSigner.signTransaction(transaction, keys);
    return transaction;
  }

  public static ExchangeRate getExchangeRate() {
    long expiryTime = Instant.now().getEpochSecond() + 10000000;
    ExchangeRateSet exchangeRateSet = RequestBuilder
        .getExchangeRateSetBuilder(1, 12, expiryTime, 1, 12, expiryTime);
    return exchangeRateSet.getCurrentRate();
  }

  public static TransactionResponse addClaim(Builder txBodyBuilder,
      List<PrivateKey> genesisPrivateKey, AccountID accountIdBuild, KeyList keyList, byte[] hash,
      CryptoServiceBlockingStub stub) {
    Duration claimDuration = RequestBuilder
        .getDuration(Instant.now(Clock.systemUTC()).getEpochSecond() + 1000000L);
    Claim claim = RequestBuilder.getClaim(accountIdBuild, claimDuration, keyList, hash);
    CryptoAddClaimTransactionBody addClaimTransactionBody = CryptoAddClaimTransactionBody
        .newBuilder().setClaim(claim).build();
    txBodyBuilder.setCryptoAddClaim(addClaimTransactionBody);
    ByteString bodyBytes = ByteString.copyFrom(txBodyBuilder.build().toByteArray());
    Transaction addClaimTx = Transaction.newBuilder().setBodyBytes(bodyBytes)
        .setSigs(SignatureList.newBuilder().getDefaultInstanceForType()).build();
    Transaction signedAddClaimTx = TransactionSigner
        .signTransaction(addClaimTx, genesisPrivateKey);
    return stub.addClaim(signedAddClaimTx);
  }

  public static  void genWacl(int numKeys, List<Key> waclPubKeyList,
      List<PrivateKey> waclPrivKeyList) {
    for (int i = 0; i < numKeys; i++) {
      KeyPair pair = new KeyPairGenerator().generateKeyPair();
      byte[] pubKey = ((EdDSAPublicKey) pair.getPublic()).getAbyte();
      Key waclKey = Key.newBuilder().setEd25519(ByteString.copyFrom(pubKey)).build();
      waclPubKeyList.add(waclKey);
      waclPrivKeyList.add(pair.getPrivate());
    }
  }

}